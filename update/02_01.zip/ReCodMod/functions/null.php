<?php
     //save all stats        
     require $cpath . 'ReCodMod/functions/parser/stats_opt.php';
     //null db connections	 
	 require $cpath . 'ReCodMod/functions/funcx/null_db_connection.php';	
	 //exit from while and restart
	 exit;			 
?>
