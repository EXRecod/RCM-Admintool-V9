<?php
$dir = $cpath."ReCodMod/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/databases/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_crontime/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_errors/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_logs/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_logs/archive/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_logs/archive/chat/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_cron/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_update/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_cache/"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
$dir = $cpath."ReCodMod/cache/x_logs/backup"; 
if(!is_dir($dir)) mkdir($dir, 0777, true) ;
?>